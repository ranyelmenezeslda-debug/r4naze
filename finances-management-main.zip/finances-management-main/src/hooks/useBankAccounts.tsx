import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { toast } from 'sonner';

export interface BankAccount {
  id: string;
  user_id: string;
  bank_name: string;
  account_type: string;
  balance: number;
  created_at: string;
  updated_at: string;
}

export const useBankAccounts = () => {
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetchBankAccounts();
    } else {
      setBankAccounts([]);
      setLoading(false);
    }
  }, [user]);

  const fetchBankAccounts = async () => {
    if (!user) return;
    
    setLoading(true);
    const { data, error } = await supabase
      .from('bank_accounts')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      toast.error('Erro ao carregar contas bancárias');
      console.error('Error fetching bank accounts:', error);
    } else {
      setBankAccounts((data || []) as BankAccount[]);
    }
    setLoading(false);
  };

  const addBankAccount = async (bankName: string, accountType: string = 'conta-corrente', initialBalance: number = 0): Promise<boolean> => {
    if (!user) return;

    const bankAccountData = {
      user_id: user.id,
      bank_name: bankName,
      account_type: accountType,
      balance: initialBalance,
    };

    const { data, error } = await supabase
      .from('bank_accounts')
      .insert([bankAccountData])
      .select()
      .single();

    if (error) {
      toast.error('Erro ao adicionar conta bancária');
      console.error('Error adding bank account:', error);
      return false;
    } else {
      setBankAccounts(prev => [data as BankAccount, ...prev]);
      toast.success('Conta bancária adicionada com sucesso!');
      return true;
    }
  };

  const deleteBankAccount = async (id: string) => {
    if (!user) return;

    const { error } = await supabase
      .from('bank_accounts')
      .delete()
      .eq('id', id)
      .eq('user_id', user.id);

    if (error) {
      toast.error('Erro ao excluir conta bancária');
      console.error('Error deleting bank account:', error);
    } else {
      setBankAccounts(prev => prev.filter(account => account.id !== id));
      toast.success('Conta bancária excluída com sucesso!');
    }
  };

  const updateBankAccount = async (id: string, updates: Partial<BankAccount>) => {
    if (!user) return;

    const { data, error } = await supabase
      .from('bank_accounts')
      .update(updates)
      .eq('id', id)
      .eq('user_id', user.id)
      .select()
      .single();

    if (error) {
      toast.error('Erro ao atualizar conta bancária');
      console.error('Error updating bank account:', error);
    } else {
      setBankAccounts(prev => prev.map(account => 
        account.id === id ? data as BankAccount : account
      ));
      toast.success('Conta bancária atualizada com sucesso!');
    }
  };

  const updateBankAccountBalance = (bankAccountId: string, amount: number, type: 'income' | 'expense') => {
    setBankAccounts(prev => prev.map(account => {
      if (account.id === bankAccountId) {
        const balanceChange = type === 'income' ? amount : -amount;
        return {
          ...account,
          balance: account.balance + balanceChange
        };
      }
      return account;
    }));
  };

  return {
    bankAccounts,
    loading,
    addBankAccount,
    deleteBankAccount,
    updateBankAccount,
    updateBankAccountBalance,
    refetch: fetchBankAccounts
  };
};