import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { Transaction } from '@/types/transaction';
import { toast } from 'sonner';

export const useTransactions = (onBalanceUpdate?: (bankAccountId: string, amount: number, type: 'income' | 'expense') => void) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetchTransactions();
    } else {
      setTransactions([]);
      setLoading(false);
    }
  }, [user]);

  const fetchTransactions = async () => {
    if (!user) return;
    
    setLoading(true);
    const { data, error } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      toast.error('Erro ao carregar transações');
      console.error('Error fetching transactions:', error);
    } else {
      setTransactions((data || []) as Transaction[]);
    }
    setLoading(false);
  };

  const addTransaction = async (newTransaction: Omit<Transaction, 'id'>) => {
    if (!user) return;

    const transactionData = {
      ...newTransaction,
      user_id: user.id,
    };

    const { data, error } = await supabase
      .from('transactions')
      .insert([transactionData])
      .select()
      .single();

    if (error) {
      toast.error('Erro ao adicionar transação');
      console.error('Error adding transaction:', error);
    } else {
      const transaction = data as Transaction;
      setTransactions(prev => [transaction, ...prev]);
      
      // Update bank account balance if account is specified
      if (transaction.bank_account_id && onBalanceUpdate) {
        onBalanceUpdate(transaction.bank_account_id, transaction.amount, transaction.type);
      }
      
      toast.success('Transação adicionada com sucesso!');
      // Force page reload to update all balances
      setTimeout(() => window.location.reload(), 1000);
    }
  };

  const deleteTransaction = async (id: string) => {
    if (!user) return;

    const { error } = await supabase
      .from('transactions')
      .delete()
      .eq('id', id)
      .eq('user_id', user.id);

    if (error) {
      toast.error('Erro ao excluir transação');
      console.error('Error deleting transaction:', error);
    } else {
      const deletedTransaction = transactions.find(t => t.id === id);
      setTransactions(prev => prev.filter(t => t.id !== id));
      
      // Update bank account balance if account was specified
      if (deletedTransaction?.bank_account_id && onBalanceUpdate) {
        // Reverse the transaction effect
        const reversedType = deletedTransaction.type === 'income' ? 'expense' : 'income';
        onBalanceUpdate(deletedTransaction.bank_account_id, deletedTransaction.amount, reversedType);
      }
      
      toast.success('Transação excluída com sucesso!');
    }
  };

  return {
    transactions,
    loading,
    addTransaction,
    deleteTransaction,
    refetch: fetchTransactions
  };
};