import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { toast } from 'sonner';

export interface Profile {
  id: string;
  user_id: string;
  email: string | null;
  display_name: string | null;
  created_at: string;
  updated_at: string;
}

export const useProfile = () => {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetchProfile();
    } else {
      setProfile(null);
      setLoading(false);
    }
  }, [user]);

  const fetchProfile = async () => {
    if (!user) return;
    
    setLoading(true);
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', user.id)
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        // Profile doesn't exist, create one
        await createProfile();
      } else {
        toast.error('Erro ao carregar perfil');
        console.error('Error fetching profile:', error);
      }
    } else {
      setProfile(data as Profile);
    }
    setLoading(false);
  };

  const createProfile = async () => {
    if (!user) return;

    const profileData = {
      user_id: user.id,
      email: user.email,
      display_name: user.email?.split('@')[0] || 'Usuário'
    };

    const { data, error } = await supabase
      .from('profiles')
      .insert([profileData])
      .select()
      .single();

    if (error) {
      toast.error('Erro ao criar perfil');
      console.error('Error creating profile:', error);
    } else {
      setProfile(data as Profile);
      toast.success('Perfil criado com sucesso!');
    }
  };

  const updateProfile = async (updates: Partial<Profile>) => {
    if (!user || !profile) return;

    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('user_id', user.id)
      .select()
      .single();

    if (error) {
      toast.error('Erro ao atualizar perfil');
      console.error('Error updating profile:', error);
    } else {
      setProfile(data as Profile);
      toast.success('Perfil atualizado com sucesso!');
    }
  };

  return {
    profile,
    loading,
    updateProfile,
    refetch: fetchProfile
  };
};