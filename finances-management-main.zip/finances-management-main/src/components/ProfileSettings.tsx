import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useProfile } from '@/hooks/useProfile';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import { Settings, Mail, Lock, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const ProfileSettings = () => {
  const { user, updateEmail, updatePassword, deleteAccount } = useAuth();
  const { profile, updateProfile } = useProfile();
  const navigate = useNavigate();
  
  const [newEmail, setNewEmail] = useState(user?.email || '');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState(profile?.display_name || '');
  const [loading, setLoading] = useState(false);

  const handleUpdateEmail = async () => {
    if (!newEmail || newEmail === user?.email) {
      toast.error('Digite um novo e-mail válido');
      return;
    }

    setLoading(true);
    const { error } = await updateEmail(newEmail);
    
    if (error) {
      toast.error('Erro ao atualizar e-mail: ' + error.message);
    } else {
      toast.success('E-mail atualizado com sucesso! Verifique sua caixa de entrada.');
    }
    setLoading(false);
  };

  const handleUpdatePassword = async () => {
    if (!newPassword || newPassword.length < 6) {
      toast.error('A senha deve ter pelo menos 6 caracteres');
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error('As senhas não coincidem');
      return;
    }

    setLoading(true);
    const { error } = await updatePassword(newPassword);
    
    if (error) {
      toast.error('Erro ao atualizar senha: ' + error.message);
    } else {
      toast.success('Senha atualizada com sucesso!');
      setNewPassword('');
      setConfirmPassword('');
    }
    setLoading(false);
  };

  const handleUpdateDisplayName = async () => {
    if (!displayName.trim()) {
      toast.error('Digite um nome válido');
      return;
    }

    setLoading(true);
    await updateProfile({ display_name: displayName });
    setLoading(false);
  };

  const handleDeleteAccount = async () => {
    setLoading(true);
    const { error } = await deleteAccount();
    
    if (error) {
      toast.error('Erro ao excluir conta: ' + error.message);
      setLoading(false);
    } else {
      toast.success('Conta excluída com sucesso!');
      navigate('/auth');
    }
  };

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Configurações do Perfil
        </CardTitle>
        <CardDescription>
          Gerencie suas informações pessoais e configurações de conta
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Nome de exibição */}
        <div className="space-y-2">
          <Label htmlFor="displayName">Nome de Exibição</Label>
          <div className="flex gap-2">
            <Input
              id="displayName"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Seu nome de exibição"
            />
            <Button 
              onClick={handleUpdateDisplayName}
              disabled={loading || !displayName.trim() || displayName === profile?.display_name}
            >
              Atualizar
            </Button>
          </div>
        </div>

        {/* Atualizar e-mail */}
        <div className="space-y-2">
          <Label htmlFor="email" className="flex items-center gap-2">
            <Mail className="h-4 w-4" />
            E-mail
          </Label>
          <div className="flex gap-2">
            <Input
              id="email"
              type="email"
              value={newEmail}
              onChange={(e) => setNewEmail(e.target.value)}
              placeholder="Novo e-mail"
            />
            <Button 
              onClick={handleUpdateEmail}
              disabled={loading || !newEmail || newEmail === user?.email}
            >
              Atualizar
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            Você receberá um e-mail de confirmação para validar o novo endereço.
          </p>
        </div>

        {/* Atualizar senha */}
        <div className="space-y-3">
          <Label className="flex items-center gap-2">
            <Lock className="h-4 w-4" />
            Alterar Senha
          </Label>
          <div className="space-y-2">
            <Input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Nova senha (mín. 6 caracteres)"
            />
            <Input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirmar nova senha"
            />
            <Button 
              onClick={handleUpdatePassword}
              disabled={loading || !newPassword || newPassword !== confirmPassword}
              className="w-full"
            >
              Atualizar Senha
            </Button>
          </div>
        </div>

        {/* Excluir conta */}
        <div className="border-t pt-6">
          <div className="space-y-3">
            <Label className="flex items-center gap-2 text-destructive">
              <Trash2 className="h-4 w-4" />
              Zona de Perigo
            </Label>
            <p className="text-sm text-muted-foreground">
              Esta ação é irreversível. Todos os seus dados serão permanentemente excluídos.
            </p>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" disabled={loading}>
                  Excluir Conta Permanentemente
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Tem certeza absoluta?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Esta ação não pode ser desfeita. Isso excluirá permanentemente sua conta
                    e removerá todos os seus dados de nossos servidores, incluindo:
                    <br />• Todas as suas transações
                    <br />• Todas as suas contas bancárias
                    <br />• Seu perfil e configurações
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleDeleteAccount}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    Sim, excluir permanentemente
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};