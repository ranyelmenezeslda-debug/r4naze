import { Transaction } from '@/types/transaction';
import { BankAccount } from '@/hooks/useBankAccounts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, BarChart, Bar, XAxis, YAxis } from 'recharts';
import { Building } from 'lucide-react';

interface BankAccountChartProps {
  transactions: Transaction[];
  bankAccounts: BankAccount[];
}

// Função para gerar cores para as contas
const generateAccountColor = (index: number) => {
  const colors = [
    'hsl(221, 83%, 53%)', // Azul primário
    'hsl(142, 71%, 45%)', // Verde vibrante
    'hsl(45, 90%, 55%)',  // Amarelo/Dourado
    'hsl(348, 83%, 47%)', // Vermelho vibrante
    'hsl(262, 83%, 58%)', // Roxo vibrante
    'hsl(210, 40%, 60%)', // Azul acinzentado
    'hsl(16, 85%, 55%)',  // Laranja coral
    'hsl(330, 75%, 60%)', // Rosa vibrante
    'hsl(75, 60%, 50%)',  // Verde amarelado
    'hsl(260, 70%, 55%)', // Roxo azulado
  ];
  
  return colors[index % colors.length];
};

export function BankAccountChart({ transactions, bankAccounts }: BankAccountChartProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Calcular saldo de cada conta (usar o mesmo cálculo do FinancialSummary)
  const calculateAccountBalance = (accountId: string) => {
    const account = bankAccounts.find(acc => acc.id === accountId);
    if (!account) return 0;
    
    // Usar apenas o saldo da conta, sem duplicar com transações
    // pois o saldo da conta já reflete o estado atual
    return account.balance || 0;
  };

  // Preparar dados dos saldos das contas
  const balanceData = bankAccounts
    .map((account, index) => {
      const calculatedBalance = calculateAccountBalance(account.id);
      return {
        name: account.bank_name,
        value: Math.abs(calculatedBalance), // Usar valor absoluto para o gráfico
        actualValue: calculatedBalance,
        fill: generateAccountColor(index),
        isNegative: calculatedBalance < 0
      };
    })
    .filter(account => account.value !== 0); // Mostrar apenas contas com saldo

  // Contar transações por conta bancária
  const accountUsage = bankAccounts.map((account, index) => {
    const accountTransactions = transactions.filter(t => t.bank_account_id === account.id);
    return {
      name: account.bank_name.length > 10 ? account.bank_name.substring(0, 10) + '...' : account.bank_name,
      fullName: account.bank_name,
      transactions: accountTransactions.length,
      fill: generateAccountColor(index)
    };
  }).filter(data => data.transactions > 0);

  // Transações sem conta especificada
  const transactionsWithoutAccount = transactions.filter(t => !t.bank_account_id || t.bank_account_id === 'no-account').length;
  if (transactionsWithoutAccount > 0) {
    accountUsage.push({
      name: 'Sem Conta Especificada',
      fullName: 'Sem Conta Especificada',
      transactions: transactionsWithoutAccount,
      fill: 'hsl(210, 20%, 70%)'
    });
  }

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length > 0) {
      const data = payload[0].payload;
      if (data.actualValue !== undefined) {
        return (
          <div className="bg-background border rounded-lg p-2 shadow-lg">
            <p className="font-medium">{data.name}</p>
            <p className={`${data.isNegative ? 'text-expense' : 'text-income'}`}>
              Saldo: {formatCurrency(data.actualValue)}
            </p>
          </div>
        );
      } else {
        return (
          <div className="bg-background border rounded-lg p-2 shadow-lg">
            <p className="font-medium">{data.fullName}</p>
            <p className="text-primary">
              {data.transactions} transação{data.transactions !== 1 ? 'ões' : ''}
            </p>
          </div>
        );
      }
    }
    return null;
  };

  if (bankAccounts.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building className="h-5 w-5" />
            Distribuição de Contas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Building className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">
              Cadastre contas bancárias para visualizar a distribuição.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Gráfico de Saldos das Contas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building className="h-5 w-5" />
            Saldos por Conta
          </CardTitle>
        </CardHeader>
        <CardContent>
          {balanceData.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">
                Nenhuma conta com saldo para exibir.
              </p>
            </div>
          ) : (
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={balanceData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={120}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {balanceData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                  <Legend 
                    formatter={(value, entry: any) => (
                      <span className={entry.payload.isNegative ? 'text-expense' : 'text-income'}>
                        {value} - {formatCurrency(entry.payload.actualValue)}
                      </span>
                    )}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Gráfico de Uso das Contas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building className="h-5 w-5" />
            Uso das Contas (Transações)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {accountUsage.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">
                Nenhuma transação para exibir.
              </p>
            </div>
          ) : (
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={accountUsage} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                  <XAxis 
                    dataKey="name" 
                    angle={-45}
                    textAnchor="end"
                    height={80}
                    fontSize={12}
                  />
                  <YAxis />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="transactions" radius={[4, 4, 0, 0]}>
                    {accountUsage.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}