import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Transaction } from '@/types/transaction';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { PieChart as PieChartIcon } from 'lucide-react';

interface ExpenseChartProps {
  transactions: Transaction[];
}

// Função para gerar cores automaticamente
const generateColor = (index: number) => {
  const baseColors = [
    'hsl(221, 83%, 53%)', // Azul primário
    'hsl(210, 40%, 60%)', // Azul acinzentado
    'hsl(142, 71%, 45%)', // Verde vibrante
    'hsl(220, 70%, 55%)', // Azul vibrante
    'hsl(142, 70%, 45%)', // Verde
    'hsl(45, 90%, 55%)',  // Amarelo/Dourado
    'hsl(0, 70%, 60%)',   // Vermelho
    'hsl(280, 65%, 60%)', // Roxo
    'hsl(195, 70%, 55%)', // Azul claro
    'hsl(25, 80%, 55%)',  // Laranja
    'hsl(160, 60%, 45%)', // Verde água
    'hsl(340, 70%, 55%)', // Rosa
    'hsl(60, 70%, 50%)',  // Amarelo limão
    'hsl(300, 60%, 50%)', // Magenta
    'hsl(180, 50%, 45%)', // Ciano
    'hsl(15, 75%, 55%)',  // Coral
    'hsl(270, 55%, 60%)', // Violeta
    'hsl(120, 65%, 50%)', // Verde lima
    'hsl(35, 85%, 60%)',  // Laranja dourado
    'hsl(200, 80%, 50%)', // Azul oceano
    'hsl(16, 85%, 55%)',  // Laranja coral
    'hsl(330, 75%, 60%)', // Rosa vibrante
    'hsl(75, 60%, 50%)',  // Verde amarelado
    'hsl(260, 70%, 55%)', // Roxo azulado
  ];
  
  // Se temos mais categorias que cores base, gerar cores automaticamente
  if (index < baseColors.length) {
    return baseColors[index];
  }
  
  // Gerar cores com base no índice usando HSL
  const hue = (index * 137.5) % 360; // Golden angle approximation
  const saturation = 60 + (index % 3) * 10; // Varia entre 60-80%
  const lightness = 45 + (index % 4) * 5;   // Varia entre 45-60%
  return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
};

export const ExpenseChart = ({ transactions }: ExpenseChartProps) => {
  // Filtrar apenas despesas e agrupar por categoria
  const expenses = transactions.filter(t => t.type === 'expense');
  
  if (expenses.length === 0) {
    return (
      <Card className="w-full">
        <CardHeader className="flex flex-row items-center gap-2">
          <PieChartIcon className="h-5 w-5 text-primary" />
          <div>
            <CardTitle>Distribuição de Despesas</CardTitle>
            <CardDescription>Por categoria em porcentagem</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-64 text-muted-foreground">
            <div className="text-center">
              <PieChartIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Nenhuma despesa encontrada</p>
              <p className="text-sm">Adicione algumas despesas para ver o gráfico</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Agrupar despesas por categoria e calcular totais
  const categoryTotals = expenses.reduce((acc, transaction) => {
    const category = transaction.category;
    acc[category] = (acc[category] || 0) + Math.abs(transaction.amount);
    return acc;
  }, {} as Record<string, number>);

  // Converter para formato do gráfico
  const chartData = Object.entries(categoryTotals).map(([category, amount]) => ({
    name: category,
    value: amount,
    percentage: 0 // Será calculado abaixo
  }));

  // Calcular total geral e porcentagens
  const totalExpenses = chartData.reduce((sum, item) => sum + item.value, 0);
  
  const chartDataWithPercentage = chartData.map(item => ({
    ...item,
    percentage: ((item.value / totalExpenses) * 100)
  }));

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-background border border-border p-3 rounded-lg shadow-lg">
          <p className="font-medium">{data.name}</p>
          <p className="text-primary">{formatCurrency(data.value)}</p>
          <p className="text-sm text-muted-foreground">
            {data.percentage.toFixed(1)}% do total
          </p>
        </div>
      );
    }
    return null;
  };

  const CustomLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
    if (percent < 0.05) return null; // Não mostrar label para fatias muito pequenas (<5%)
    
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text 
        x={x} 
        y={y} 
        fill="white" 
        textAnchor={x > cx ? 'start' : 'end'} 
        dominantBaseline="central"
        fontSize="12"
        fontWeight="500"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center gap-2">
        <PieChartIcon className="h-5 w-5 text-primary" />
        <div>
          <CardTitle>Distribuição de Despesas</CardTitle>
          <CardDescription>
            Total: {formatCurrency(totalExpenses)} • Por categoria em porcentagem
          </CardDescription>
        </div>
      </CardHeader>
      <CardContent className="p-3 sm:p-6">
        <div className="w-full h-72 sm:h-80">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart margin={{ top: 10, right: 10, bottom: 40, left: 10 }}>
              <Pie
                data={chartDataWithPercentage}
                cx="50%"
                cy="45%"
                labelLine={false}
                label={CustomLabel}
                outerRadius="60%"
                fill="#8884d8"
                dataKey="value"
              >
                {chartDataWithPercentage.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={generateColor(index)} 
                  />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                verticalAlign="bottom" 
                height={30}
                wrapperStyle={{
                  fontSize: '12px',
                  paddingTop: '8px'
                }}
                formatter={(value, entry) => (
                  <span 
                    style={{ 
                      color: entry.color,
                      fontSize: 'inherit'
                    }}
                    className="text-xs sm:text-sm break-words"
                  >
                    {value.length > 15 ? `${value.substring(0, 12)}...` : value} ({((entry.payload?.value || 0) / totalExpenses * 100).toFixed(1)}%)
                  </span>
                )}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};