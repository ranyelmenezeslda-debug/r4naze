import { Transaction } from '@/types/transaction';
import { BankAccount } from '@/hooks/useBankAccounts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowUpIcon, ArrowDownIcon, DollarSignIcon, Building } from 'lucide-react';

interface FinancialSummaryProps {
  transactions: Transaction[];
  bankAccounts: BankAccount[];
}

export function FinancialSummary({ transactions, bankAccounts }: FinancialSummaryProps) {
  const income = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
    
  const expenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);
    
  const transactionBalance = income - expenses;
  
  // Total balance from all bank accounts
  const bankAccountsBalance = bankAccounts.reduce((sum, account) => sum + account.balance, 0);
  
  // For display purposes, we show the bank accounts total as the actual balance
  const totalBalance = bankAccountsBalance;
  
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <Card className="border-l-4 border-l-income">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Receitas
          </CardTitle>
          <ArrowUpIcon className="h-4 w-4 text-income" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-income">
            {formatCurrency(income)}
          </div>
        </CardContent>
      </Card>
      
      <Card className="border-l-4 border-l-expense">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Despesas
          </CardTitle>
          <ArrowDownIcon className="h-4 w-4 text-expense" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-expense">
            {formatCurrency(expenses)}
          </div>
        </CardContent>
      </Card>
      
      <Card className={`border-l-4 ${totalBalance >= 0 ? 'border-l-income' : 'border-l-expense'}`}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Saldo Total
          </CardTitle>
          <Building className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className={`text-2xl font-bold ${totalBalance >= 0 ? 'text-income' : 'text-expense'}`}>
            {formatCurrency(totalBalance)}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Soma de todas as contas bancárias
          </p>
        </CardContent>
      </Card>
    </div>
  );
}