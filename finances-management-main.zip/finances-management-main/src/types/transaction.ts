export interface Transaction {
  id: string;
  description: string;
  amount: number;
  category: string;
  date: string;
  type: 'income' | 'expense';
  user_id?: string;
  bank_account_id?: string;
  created_at?: string;
  updated_at?: string;
}

export const CATEGORIES = [
  'Alimentação',
  'Transporte', 
  'Moradia',
  'Saúde',
  'Educação',
  'Entretenimento',
  'Vestuário',
  'Salário',
  'Freelance',
  'Investimentos',
  'Outros'
] as const;