import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useTransactions } from '@/hooks/useTransactions';
import { useBankAccounts } from '@/hooks/useBankAccounts';
import { useProfile } from '@/hooks/useProfile';
import { FinancialSummary } from '@/components/FinancialSummary';
import { TransactionForm } from '@/components/TransactionForm';
import { TransactionTable } from '@/components/TransactionTable';
import { ExpenseChart } from '@/components/ExpenseChart';
import { BankAccountsManager } from '@/components/BankAccountsManager';
import { BankAccountBalanceChart } from '@/components/BankAccountBalanceChart';
import { BankAccountUsageChart } from '@/components/BankAccountUsageChart';
import { Button } from '@/components/ui/button';
import { CalculatorIcon, LogOut, User, Settings } from 'lucide-react';

const Index = () => {
  const { user, loading: authLoading, signOut } = useAuth();
  const { bankAccounts, loading: bankAccountsLoading, updateBankAccountBalance } = useBankAccounts();
  const { transactions, loading: transactionsLoading, addTransaction, deleteTransaction } = useTransactions(updateBankAccountBalance);
  const { profile, loading: profileLoading } = useProfile();
  const navigate = useNavigate();

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-muted flex items-center justify-center">
        <div className="bg-white text-black dark:bg-gray-900 dark:text-white">
          <h1 className="text-2xl font-bold">Aguarde só um momento.</h1>
          <CalculatorIcon className="h-8 w-8 animate-pulse mx-auto mb-4 text-primary" />
          <p>Carregando...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const handleSignOut = async () => {
    await signOut();
    navigate('/auth');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      <header className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-lg">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 sm:gap-0">
            <div className="flex items-center gap-3">
              <CalculatorIcon className="h-6 w-6 sm:h-8 sm:w-8" />
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold">Controle de Finanças</h1>
                <p className="text-primary-foreground/80 mt-1 text-sm sm:text-base">
                  Gerencie suas finanças de forma rápida e organizada.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
              <div className="flex items-center gap-2 text-primary-foreground/80">
                <User className="h-4 w-4" />
                <span className="text-sm truncate max-w-32 sm:max-w-none">
                  {profileLoading ? 'Carregando...' : (profile?.display_name || user.email)}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate('/profile')}
                  className="bg-transparent border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10 flex-shrink-0"
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Perfil
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSignOut}
                  className="bg-transparent border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10 flex-shrink-0"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sair
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 max-w-7xl">
        {transactionsLoading ? (
          <div className="text-center py-8">
            <p>Carregando transações...</p>
          </div>
        ) : (
          <>
            <FinancialSummary transactions={transactions} bankAccounts={bankAccounts} />
            <BankAccountsManager />
            <TransactionForm onAddTransaction={addTransaction} bankAccounts={bankAccounts} />
            
            <div className="space-y-6 mb-6">
              {/* Gráficos lado a lado no desktop */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="w-full">
                  <ExpenseChart transactions={transactions} />
                </div>
                <div className="w-full">
                  <BankAccountBalanceChart 
                    transactions={transactions} 
                    bankAccounts={bankAccounts}
                  />
                </div>
              </div>
              
              {/* Gráfico de uso das contas em linha separada */}
              <div className="w-full">
                <BankAccountUsageChart 
                  transactions={transactions} 
                  bankAccounts={bankAccounts}
                />
              </div>
            </div>
            
            <TransactionTable 
              transactions={transactions} 
              onDeleteTransaction={deleteTransaction} 
            />
          </>
        )}
      </main>
    </div>
  );
};
export default Index;