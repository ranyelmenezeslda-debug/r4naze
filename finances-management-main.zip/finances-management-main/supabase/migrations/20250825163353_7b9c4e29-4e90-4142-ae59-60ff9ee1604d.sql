-- Corrigir problema de função sem search_path seguro
ALTER FUNCTION public.update_updated_at_column() SET search_path = '';
ALTER FUNCTION public.update_bank_account_balance() SET search_path = '';

-- Verificar se há alguma tabela com RLS habilitado mas sem políticas
-- e desabilitar RLS na tabela movies já que ela não é usada no sistema financeiro
ALTER TABLE public.movies DISABLE ROW LEVEL SECURITY;