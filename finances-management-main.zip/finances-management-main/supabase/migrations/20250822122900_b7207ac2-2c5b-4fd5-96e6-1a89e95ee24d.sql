-- Fix null id values in transactions table
UPDATE public.transactions 
SET id = gen_random_uuid() 
WHERE id IS NULL;

-- Now set the constraints
ALTER TABLE public.transactions 
ALTER COLUMN id SET DEFAULT gen_random_uuid(),
ALTER COLUMN id SET NOT NULL;