
-- Criar tabela para contas bancárias
CREATE TABLE public.bank_accounts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  bank_name TEXT NOT NULL,
  account_type TEXT DEFAULT 'conta-corrente',
  balance NUMERIC DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS na tabela bank_accounts
ALTER TABLE public.bank_accounts ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para bank_accounts
CREATE POLICY "Users can view their own bank accounts" 
  ON public.bank_accounts 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own bank accounts" 
  ON public.bank_accounts 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own bank accounts" 
  ON public.bank_accounts 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own bank accounts" 
  ON public.bank_accounts 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Adicionar coluna bank_account_id à tabela transactions
ALTER TABLE public.transactions ADD COLUMN bank_account_id UUID REFERENCES public.bank_accounts(id);

-- Trigger para atualizar updated_at em bank_accounts
CREATE TRIGGER update_bank_accounts_updated_at
  BEFORE UPDATE ON public.bank_accounts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Função para atualizar saldo das contas bancárias
CREATE OR REPLACE FUNCTION update_bank_account_balance()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Atualizar saldo ao inserir transação
    IF NEW.bank_account_id IS NOT NULL THEN
      UPDATE public.bank_accounts 
      SET balance = balance + (CASE WHEN NEW.type = 'income' THEN NEW.amount ELSE -NEW.amount END)
      WHERE id = NEW.bank_account_id;
    END IF;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    -- Reverter saldo ao deletar transação
    IF OLD.bank_account_id IS NOT NULL THEN
      UPDATE public.bank_accounts 
      SET balance = balance - (CASE WHEN OLD.type = 'income' THEN OLD.amount ELSE -OLD.amount END)
      WHERE id = OLD.bank_account_id;
    END IF;
    RETURN OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    -- Atualizar saldo ao modificar transação
    IF OLD.bank_account_id IS NOT NULL THEN
      -- Reverter saldo antigo
      UPDATE public.bank_accounts 
      SET balance = balance - (CASE WHEN OLD.type = 'income' THEN OLD.amount ELSE -OLD.amount END)
      WHERE id = OLD.bank_account_id;
    END IF;
    
    IF NEW.bank_account_id IS NOT NULL THEN
      -- Aplicar novo saldo
      UPDATE public.bank_accounts 
      SET balance = balance + (CASE WHEN NEW.type = 'income' THEN NEW.amount ELSE -NEW.amount END)
      WHERE id = NEW.bank_account_id;
    END IF;
    RETURN NEW;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Criar trigger para atualizar saldo automaticamente
CREATE TRIGGER trigger_update_bank_balance
  AFTER INSERT OR UPDATE OR DELETE ON public.transactions
  FOR EACH ROW EXECUTE FUNCTION update_bank_account_balance();
