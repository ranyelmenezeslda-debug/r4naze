-- Create a simple policy for movies table (assuming it should be publicly readable)
CREATE POLICY "Anyone can view movies" 
ON public.movies 
FOR SELECT 
USING (true);