-- Create function to delete user account
CREATE OR REPLACE FUNCTION delete_user()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Delete the current user from auth.users
  -- This will cascade to all related data
  DELETE FROM auth.users WHERE id = auth.uid();
END;
$$;