-- Reativar RLS na tabela movies e criar política restritiva ou removê-la
-- Como a tabela movies não é usada no sistema financeiro, vou criar uma política que bloqueia acesso
ALTER TABLE public.movies ENABLE ROW LEVEL SECURITY;

-- Criar política que não permite acesso público à tabela movies
CREATE POLICY "No public access to movies"
ON public.movies FOR ALL
USING (false);