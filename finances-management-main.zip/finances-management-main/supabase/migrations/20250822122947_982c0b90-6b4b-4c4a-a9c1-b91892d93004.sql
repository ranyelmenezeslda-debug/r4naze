-- Fix security warning by enabling RLS on movies table
ALTER TABLE public.movies ENABLE ROW LEVEL SECURITY;

-- Fix function search_path security warning
ALTER FUNCTION public.handle_new_user() SET search_path = '';